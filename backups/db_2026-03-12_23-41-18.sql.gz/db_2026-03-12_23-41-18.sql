--
-- PostgreSQL database dump
--

\restrict aICQfdDQnvyNdQv2hfkOsKGtZFqSsbdYjfm9p5tUxcIvlvhbg8vdpoxbbfhTiAx

-- Dumped from database version 16.13 (Debian 16.13-1.pgdg13+1)
-- Dumped by pg_dump version 16.13 (Debian 16.13-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: RequestStatus; Type: TYPE; Schema: public; Owner: admin
--

CREATE TYPE public."RequestStatus" AS ENUM (
    'PENDING',
    'ACCEPTED',
    'REJECTED'
);


ALTER TYPE public."RequestStatus" OWNER TO admin;

--
-- Name: RoomStatus; Type: TYPE; Schema: public; Owner: admin
--

CREATE TYPE public."RoomStatus" AS ENUM (
    'WAITING',
    'STARTING',
    'IN_GAME'
);


ALTER TYPE public."RoomStatus" OWNER TO admin;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: FriendRequest; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public."FriendRequest" (
    id text NOT NULL,
    "senderId" text NOT NULL,
    "receiverId" text NOT NULL,
    status public."RequestStatus" DEFAULT 'PENDING'::public."RequestStatus" NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."FriendRequest" OWNER TO admin;

--
-- Name: Friendship; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public."Friendship" (
    id text NOT NULL,
    "user1Id" text NOT NULL,
    "user2Id" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."Friendship" OWNER TO admin;

--
-- Name: GameAction; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public."GameAction" (
    id text NOT NULL,
    "gameId" text NOT NULL,
    "playerId" text NOT NULL,
    action text NOT NULL,
    amount integer,
    phase text NOT NULL,
    round integer DEFAULT 1 NOT NULL,
    "timestamp" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."GameAction" OWNER TO admin;

--
-- Name: GameHistory; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public."GameHistory" (
    id text NOT NULL,
    "tableId" text NOT NULL,
    "gameId" text NOT NULL,
    board text[],
    pot integer NOT NULL,
    "winnerId" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."GameHistory" OWNER TO admin;

--
-- Name: GameResult; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public."GameResult" (
    id text NOT NULL,
    "gameId" text NOT NULL,
    "winnerId" text NOT NULL,
    "winnerName" text NOT NULL,
    pot integer NOT NULL,
    hands jsonb,
    "startedAt" timestamp(3) without time zone NOT NULL,
    "endedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."GameResult" OWNER TO admin;

--
-- Name: PlayerStats; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public."PlayerStats" (
    id text NOT NULL,
    "playerId" text NOT NULL,
    "totalGames" integer DEFAULT 0 NOT NULL,
    "totalWins" integer DEFAULT 0 NOT NULL,
    "totalLosses" integer DEFAULT 0 NOT NULL,
    "totalHands" integer DEFAULT 0 NOT NULL,
    "totalRaises" integer DEFAULT 0 NOT NULL,
    "totalCalls" integer DEFAULT 0 NOT NULL,
    "totalFolds" integer DEFAULT 0 NOT NULL,
    "totalChecks" integer DEFAULT 0 NOT NULL,
    "biggestPot" integer DEFAULT 0 NOT NULL,
    "biggestWin" integer DEFAULT 0 NOT NULL,
    "totalChipsWon" integer DEFAULT 0 NOT NULL,
    "totalChipsLost" integer DEFAULT 0 NOT NULL,
    "updatedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."PlayerStats" OWNER TO admin;

--
-- Name: User; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public."User" (
    id text NOT NULL,
    username text NOT NULL,
    email text NOT NULL,
    password text NOT NULL,
    chips integer DEFAULT 1000 NOT NULL,
    level integer DEFAULT 1 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."User" OWNER TO admin;

--
-- Name: UserStats; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public."UserStats" (
    id text NOT NULL,
    wins integer DEFAULT 0 NOT NULL,
    "totalGames" integer DEFAULT 0 NOT NULL,
    "biggestPot" integer DEFAULT 0 NOT NULL,
    "userId" text NOT NULL
);


ALTER TABLE public."UserStats" OWNER TO admin;

--
-- Name: _prisma_migrations; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public._prisma_migrations (
    id character varying(36) NOT NULL,
    checksum character varying(64) NOT NULL,
    finished_at timestamp with time zone,
    migration_name character varying(255) NOT NULL,
    logs text,
    rolled_back_at timestamp with time zone,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    applied_steps_count integer DEFAULT 0 NOT NULL
);


ALTER TABLE public._prisma_migrations OWNER TO admin;

--
-- Name: room_players; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.room_players (
    id text NOT NULL,
    "roomId" text NOT NULL,
    "userId" text NOT NULL,
    "isReady" boolean DEFAULT false NOT NULL,
    "joinedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "position" integer
);


ALTER TABLE public.room_players OWNER TO admin;

--
-- Name: waiting_rooms; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.waiting_rooms (
    id text NOT NULL,
    name text NOT NULL,
    "hostId" text NOT NULL,
    "maxPlayers" integer DEFAULT 9 NOT NULL,
    status public."RoomStatus" DEFAULT 'WAITING'::public."RoomStatus" NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "gameId" text
);


ALTER TABLE public.waiting_rooms OWNER TO admin;

--
-- Data for Name: FriendRequest; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public."FriendRequest" (id, "senderId", "receiverId", status, "createdAt", "updatedAt") FROM stdin;
26d97dad-eb22-4907-a3a1-886eafa59158	e50cb472-902e-4ca5-bc56-237f32aa107f	aaf423c8-962b-43bd-b96a-eae792871240	ACCEPTED	2026-03-12 01:57:42.864	2026-03-12 01:58:45.917
2cc9c986-6561-4c8e-8514-0518617b1889	e50cb472-902e-4ca5-bc56-237f32aa107f	46c37aec-865c-4beb-ae98-41608fe8086c	PENDING	2026-03-12 02:26:15.441	2026-03-12 02:26:15.441
004dcb6e-4460-43aa-aea3-7eeb59a887cf	e50cb472-902e-4ca5-bc56-237f32aa107f	e50cb472-902e-4ca5-bc56-237f32aa107f	ACCEPTED	2026-03-12 02:26:16.357	2026-03-12 02:26:19.617
\.


--
-- Data for Name: Friendship; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public."Friendship" (id, "user1Id", "user2Id", "createdAt") FROM stdin;
329cf229-e6ea-4b0f-8259-4b98847537b9	e50cb472-902e-4ca5-bc56-237f32aa107f	aaf423c8-962b-43bd-b96a-eae792871240	2026-03-12 01:58:45.928
04d880b8-d973-4471-b2e5-8ed5c93d8280	e50cb472-902e-4ca5-bc56-237f32aa107f	e50cb472-902e-4ca5-bc56-237f32aa107f	2026-03-12 02:26:19.623
\.


--
-- Data for Name: GameAction; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public."GameAction" (id, "gameId", "playerId", action, amount, phase, round, "timestamp") FROM stdin;
\.


--
-- Data for Name: GameHistory; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public."GameHistory" (id, "tableId", "gameId", board, pot, "winnerId", "createdAt") FROM stdin;
\.


--
-- Data for Name: GameResult; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public."GameResult" (id, "gameId", "winnerId", "winnerName", pot, hands, "startedAt", "endedAt") FROM stdin;
\.


--
-- Data for Name: PlayerStats; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public."PlayerStats" (id, "playerId", "totalGames", "totalWins", "totalLosses", "totalHands", "totalRaises", "totalCalls", "totalFolds", "totalChecks", "biggestPot", "biggestWin", "totalChipsWon", "totalChipsLost", "updatedAt") FROM stdin;
\.


--
-- Data for Name: User; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public."User" (id, username, email, password, chips, level, "createdAt", "updatedAt") FROM stdin;
46c37aec-865c-4beb-ae98-41608fe8086c	Toto	test@test.com	$2a$10$P4Hg.5pq8N.jnYEsfXLn5OKxDVkFqlzOicZPtmhv3bansWIUNmgwe	1000	1	2026-03-12 00:59:12.239	2026-03-12 00:59:12.239
e50cb472-902e-4ca5-bc56-237f32aa107f	teamtest	test1@qb.com	$2a$10$MNnpnfAXF70vbjUw5VyXxuuWkym/9av.ICqZdwRFaca01LKTp/7Ha	1000	1	2026-03-12 01:29:46.892	2026-03-12 01:29:46.892
aaf423c8-962b-43bd-b96a-eae792871240	testami	ami@test.com	$2a$10$X6tSpv7ZNboBiFIwP9821.RxJjoBLkRIxJQmesYHRSDAMuxT7JDzS	1000	1	2026-03-12 01:57:12.575	2026-03-12 01:57:12.575
ad365f65-8b98-41ed-9a71-c607856bbd2d	host	host@test.com	$2a$10$LYR/T0oBBTwWCRPpuYrGt.0gm23e76Q3cetxj1P..sVV82LA/1mjK	1000	1	2026-03-12 15:08:19.445	2026-03-12 15:08:19.445
6f6e08a3-7077-47a9-a931-54802b672786	player	player@test.com	$2a$10$x8MY3rDstiw9P4L426PqqeOL9MVCeziw2GaV1oVNhPnxGk48hujse	1000	1	2026-03-12 15:09:35.103	2026-03-12 15:09:35.103
6c5b169b-e0fc-4ec1-874c-3ee1a4ddf86b	player1	player1@test.com	$2a$10$V/Rp8Pu9DwH/RwaYoaB5EOUaKzHXBb23QnhZCoJFjtxNennMplIVy	1000	1	2026-03-12 17:24:38.641	2026-03-12 17:24:38.641
\.


--
-- Data for Name: UserStats; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public."UserStats" (id, wins, "totalGames", "biggestPot", "userId") FROM stdin;
97548542-e487-4019-bdf7-478de58daf32	0	0	0	46c37aec-865c-4beb-ae98-41608fe8086c
14a513dd-e788-49e3-a552-25f25788860a	0	0	0	e50cb472-902e-4ca5-bc56-237f32aa107f
6104cc63-8c1c-46d9-a069-31f1f05d7a71	0	0	0	aaf423c8-962b-43bd-b96a-eae792871240
75416e2b-142a-4674-b487-82498a133d20	0	0	0	ad365f65-8b98-41ed-9a71-c607856bbd2d
ee9ea96b-599d-494d-97e2-f9c0a6a66a4f	0	0	0	6f6e08a3-7077-47a9-a931-54802b672786
cfe036b1-ef79-4e3b-bef6-507ea0daa68a	0	0	0	6c5b169b-e0fc-4ec1-874c-3ee1a4ddf86b
\.


--
-- Data for Name: _prisma_migrations; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) FROM stdin;
abb5dfad-999a-4824-ad3f-34ebbe374278	3040fe755635fc18b52249b21809755e55cb97d5396aa713f2f2ad4e0d9d5bf3	2026-03-12 00:50:23.550509+00	20260308214341_init	\N	\N	2026-03-12 00:50:23.545522+00	1
e7c83d44-e393-4cd0-a4ea-31ca157a5aad	ec818f7e9a5dd274db96e904b69372fdf3442e1f0aef4cd12fc4197ce58af05f	2026-03-12 01:41:12.417018+00	20260312014112_add_friends	\N	\N	2026-03-12 01:41:12.412055+00	1
6962286b-30c1-49f8-a160-cfa859f382f8	58b03bdec60ecb874deae7980f41da3050562d5661768f004ecdda9ed8c01738	2026-03-12 14:46:41.374927+00	20260312144641_add_waiting_rooms	\N	\N	2026-03-12 14:46:41.369394+00	1
7214458f-6f5e-4266-ae9d-4b6f4cadccd5	b17d1bc6a8e8c85ebde04b5ef42085a4db3958c872095740e9eabc8daf485292	2026-03-12 17:19:44.974852+00	20260312171944_add_game_history	\N	\N	2026-03-12 17:19:44.97272+00	1
b069516c-d746-4660-9e12-be51b4ae6367	1693bd7b971974caa86f35f49f591266e13ebf38385ca0dce9d9db3537cc550a	2026-03-12 22:06:09.108804+00	20260312220609_add_indexes_for_optimization	\N	\N	2026-03-12 22:06:09.101764+00	1
8e88f3d8-1bbe-4aec-95a4-fac6170d845c	995388d07375b84176d074639675e3b904e2f58521a240d24d2b7f20db2f7a41	2026-03-12 22:27:16.238353+00	20260312222716_add_game_history_tables	\N	\N	2026-03-12 22:27:16.229514+00	1
\.


--
-- Data for Name: room_players; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.room_players (id, "roomId", "userId", "isReady", "joinedAt", "position") FROM stdin;
1e2dc5c0-274a-4947-9857-7820341fcf10	1441c597-8455-4cc8-886b-52a8e73c5cf4	6f6e08a3-7077-47a9-a931-54802b672786	t	2026-03-12 15:10:27.187	1
4d11c47a-ca6d-4e4f-a217-bd4431399354	1441c597-8455-4cc8-886b-52a8e73c5cf4	ad365f65-8b98-41ed-9a71-c607856bbd2d	t	2026-03-12 15:08:51.397	0
04387391-dc7d-465a-940c-842253297dc1	2d465caf-5269-4958-a11c-aad917ec8bb4	ad365f65-8b98-41ed-9a71-c607856bbd2d	t	2026-03-12 17:30:29.789	0
1615e480-baae-4e2d-a858-bd502a3296d8	2d465caf-5269-4958-a11c-aad917ec8bb4	6c5b169b-e0fc-4ec1-874c-3ee1a4ddf86b	t	2026-03-12 17:59:32.768	1
b5b51ca7-ce1e-4a16-a5d5-850ad6d510db	651a91df-ce95-4359-bbae-4ed26601ef3c	ad365f65-8b98-41ed-9a71-c607856bbd2d	t	2026-03-12 18:07:11.869	0
d7b85dc3-159f-40a3-9c36-de59db911ab4	651a91df-ce95-4359-bbae-4ed26601ef3c	6c5b169b-e0fc-4ec1-874c-3ee1a4ddf86b	t	2026-03-12 18:12:39.297	1
09a446c5-4e1e-432d-8b92-02e89969f5ff	a1f66e75-3f4a-410a-a8b1-1b35108d5cbd	ad365f65-8b98-41ed-9a71-c607856bbd2d	t	2026-03-12 18:31:05.518	0
2cdb0134-8d34-41d9-8bd4-71d376e5b6ba	a1f66e75-3f4a-410a-a8b1-1b35108d5cbd	6c5b169b-e0fc-4ec1-874c-3ee1a4ddf86b	t	2026-03-12 18:32:48.162	1
51cf5fcc-13ee-4309-b055-d60bd165ef39	94e70079-232a-4b44-88db-fd1342a1b9d1	ad365f65-8b98-41ed-9a71-c607856bbd2d	t	2026-03-12 19:06:34.735	0
65bd0841-0541-470c-a003-c3544e5b88c3	94e70079-232a-4b44-88db-fd1342a1b9d1	6c5b169b-e0fc-4ec1-874c-3ee1a4ddf86b	t	2026-03-12 19:07:47.328	1
\.


--
-- Data for Name: waiting_rooms; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.waiting_rooms (id, name, "hostId", "maxPlayers", status, "createdAt", "updatedAt", "gameId") FROM stdin;
1441c597-8455-4cc8-886b-52a8e73c5cf4	Salle de test	ad365f65-8b98-41ed-9a71-c607856bbd2d	9	IN_GAME	2026-03-12 15:08:51.397	2026-03-12 15:11:31.683	game_1773328291683
2d465caf-5269-4958-a11c-aad917ec8bb4	Salle de host	ad365f65-8b98-41ed-9a71-c607856bbd2d	9	IN_GAME	2026-03-12 17:30:29.789	2026-03-12 18:00:40.871	game_1773338440870
651a91df-ce95-4359-bbae-4ed26601ef3c	Salle de host	ad365f65-8b98-41ed-9a71-c607856bbd2d	9	IN_GAME	2026-03-12 18:07:11.869	2026-03-12 18:13:02.008	game_1773339182007
a1f66e75-3f4a-410a-a8b1-1b35108d5cbd	Salle de host	ad365f65-8b98-41ed-9a71-c607856bbd2d	9	IN_GAME	2026-03-12 18:31:05.518	2026-03-12 18:33:52.676	game_1773340432674
94e70079-232a-4b44-88db-fd1342a1b9d1	Salle de host	ad365f65-8b98-41ed-9a71-c607856bbd2d	9	IN_GAME	2026-03-12 19:06:34.735	2026-03-12 19:07:56.03	game_1773342476029
\.


--
-- Name: FriendRequest FriendRequest_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."FriendRequest"
    ADD CONSTRAINT "FriendRequest_pkey" PRIMARY KEY (id);


--
-- Name: Friendship Friendship_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."Friendship"
    ADD CONSTRAINT "Friendship_pkey" PRIMARY KEY (id);


--
-- Name: GameAction GameAction_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."GameAction"
    ADD CONSTRAINT "GameAction_pkey" PRIMARY KEY (id);


--
-- Name: GameHistory GameHistory_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."GameHistory"
    ADD CONSTRAINT "GameHistory_pkey" PRIMARY KEY (id);


--
-- Name: GameResult GameResult_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."GameResult"
    ADD CONSTRAINT "GameResult_pkey" PRIMARY KEY (id);


--
-- Name: PlayerStats PlayerStats_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."PlayerStats"
    ADD CONSTRAINT "PlayerStats_pkey" PRIMARY KEY (id);


--
-- Name: UserStats UserStats_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."UserStats"
    ADD CONSTRAINT "UserStats_pkey" PRIMARY KEY (id);


--
-- Name: User User_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."User"
    ADD CONSTRAINT "User_pkey" PRIMARY KEY (id);


--
-- Name: _prisma_migrations _prisma_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public._prisma_migrations
    ADD CONSTRAINT _prisma_migrations_pkey PRIMARY KEY (id);


--
-- Name: room_players room_players_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.room_players
    ADD CONSTRAINT room_players_pkey PRIMARY KEY (id);


--
-- Name: waiting_rooms waiting_rooms_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.waiting_rooms
    ADD CONSTRAINT waiting_rooms_pkey PRIMARY KEY (id);


--
-- Name: FriendRequest_createdAt_idx; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX "FriendRequest_createdAt_idx" ON public."FriendRequest" USING btree ("createdAt");


--
-- Name: FriendRequest_receiverId_idx; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX "FriendRequest_receiverId_idx" ON public."FriendRequest" USING btree ("receiverId");


--
-- Name: FriendRequest_senderId_idx; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX "FriendRequest_senderId_idx" ON public."FriendRequest" USING btree ("senderId");


--
-- Name: FriendRequest_senderId_receiverId_key; Type: INDEX; Schema: public; Owner: admin
--

CREATE UNIQUE INDEX "FriendRequest_senderId_receiverId_key" ON public."FriendRequest" USING btree ("senderId", "receiverId");


--
-- Name: FriendRequest_status_idx; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX "FriendRequest_status_idx" ON public."FriendRequest" USING btree (status);


--
-- Name: Friendship_user1Id_idx; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX "Friendship_user1Id_idx" ON public."Friendship" USING btree ("user1Id");


--
-- Name: Friendship_user1Id_user2Id_key; Type: INDEX; Schema: public; Owner: admin
--

CREATE UNIQUE INDEX "Friendship_user1Id_user2Id_key" ON public."Friendship" USING btree ("user1Id", "user2Id");


--
-- Name: Friendship_user2Id_idx; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX "Friendship_user2Id_idx" ON public."Friendship" USING btree ("user2Id");


--
-- Name: GameAction_gameId_idx; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX "GameAction_gameId_idx" ON public."GameAction" USING btree ("gameId");


--
-- Name: GameAction_playerId_idx; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX "GameAction_playerId_idx" ON public."GameAction" USING btree ("playerId");


--
-- Name: GameAction_timestamp_idx; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX "GameAction_timestamp_idx" ON public."GameAction" USING btree ("timestamp");


--
-- Name: GameResult_endedAt_idx; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX "GameResult_endedAt_idx" ON public."GameResult" USING btree ("endedAt");


--
-- Name: GameResult_gameId_idx; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX "GameResult_gameId_idx" ON public."GameResult" USING btree ("gameId");


--
-- Name: GameResult_gameId_key; Type: INDEX; Schema: public; Owner: admin
--

CREATE UNIQUE INDEX "GameResult_gameId_key" ON public."GameResult" USING btree ("gameId");


--
-- Name: GameResult_winnerId_idx; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX "GameResult_winnerId_idx" ON public."GameResult" USING btree ("winnerId");


--
-- Name: PlayerStats_playerId_idx; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX "PlayerStats_playerId_idx" ON public."PlayerStats" USING btree ("playerId");


--
-- Name: PlayerStats_playerId_key; Type: INDEX; Schema: public; Owner: admin
--

CREATE UNIQUE INDEX "PlayerStats_playerId_key" ON public."PlayerStats" USING btree ("playerId");


--
-- Name: PlayerStats_totalGames_idx; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX "PlayerStats_totalGames_idx" ON public."PlayerStats" USING btree ("totalGames");


--
-- Name: PlayerStats_totalWins_idx; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX "PlayerStats_totalWins_idx" ON public."PlayerStats" USING btree ("totalWins");


--
-- Name: UserStats_userId_key; Type: INDEX; Schema: public; Owner: admin
--

CREATE UNIQUE INDEX "UserStats_userId_key" ON public."UserStats" USING btree ("userId");


--
-- Name: User_createdAt_idx; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX "User_createdAt_idx" ON public."User" USING btree ("createdAt");


--
-- Name: User_email_idx; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX "User_email_idx" ON public."User" USING btree (email);


--
-- Name: User_email_key; Type: INDEX; Schema: public; Owner: admin
--

CREATE UNIQUE INDEX "User_email_key" ON public."User" USING btree (email);


--
-- Name: User_username_idx; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX "User_username_idx" ON public."User" USING btree (username);


--
-- Name: User_username_key; Type: INDEX; Schema: public; Owner: admin
--

CREATE UNIQUE INDEX "User_username_key" ON public."User" USING btree (username);


--
-- Name: room_players_roomId_userId_key; Type: INDEX; Schema: public; Owner: admin
--

CREATE UNIQUE INDEX "room_players_roomId_userId_key" ON public.room_players USING btree ("roomId", "userId");


--
-- Name: FriendRequest FriendRequest_receiverId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."FriendRequest"
    ADD CONSTRAINT "FriendRequest_receiverId_fkey" FOREIGN KEY ("receiverId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: FriendRequest FriendRequest_senderId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."FriendRequest"
    ADD CONSTRAINT "FriendRequest_senderId_fkey" FOREIGN KEY ("senderId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Friendship Friendship_user1Id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."Friendship"
    ADD CONSTRAINT "Friendship_user1Id_fkey" FOREIGN KEY ("user1Id") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Friendship Friendship_user2Id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."Friendship"
    ADD CONSTRAINT "Friendship_user2Id_fkey" FOREIGN KEY ("user2Id") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: GameAction GameAction_playerId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."GameAction"
    ADD CONSTRAINT "GameAction_playerId_fkey" FOREIGN KEY ("playerId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: GameHistory GameHistory_winnerId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."GameHistory"
    ADD CONSTRAINT "GameHistory_winnerId_fkey" FOREIGN KEY ("winnerId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: GameResult GameResult_winnerId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."GameResult"
    ADD CONSTRAINT "GameResult_winnerId_fkey" FOREIGN KEY ("winnerId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: PlayerStats PlayerStats_playerId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."PlayerStats"
    ADD CONSTRAINT "PlayerStats_playerId_fkey" FOREIGN KEY ("playerId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: UserStats UserStats_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."UserStats"
    ADD CONSTRAINT "UserStats_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: room_players room_players_roomId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.room_players
    ADD CONSTRAINT "room_players_roomId_fkey" FOREIGN KEY ("roomId") REFERENCES public.waiting_rooms(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: room_players room_players_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.room_players
    ADD CONSTRAINT "room_players_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- PostgreSQL database dump complete
--

\unrestrict aICQfdDQnvyNdQv2hfkOsKGtZFqSsbdYjfm9p5tUxcIvlvhbg8vdpoxbbfhTiAx

